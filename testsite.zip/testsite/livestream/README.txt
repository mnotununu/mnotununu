 1.  Copy your media files and paste it in media folder
 
 2.  Open "video-list.js" and change name of your videos and videos src

 
