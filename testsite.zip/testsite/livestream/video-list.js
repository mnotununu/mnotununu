let allVideos = [
   {
      name: "Intro:Ewe Nje Studios",
      src: "Art/Intro",
      id: "vid_1"
   },
   {
      name: "Stay-Solid",
      src: "Art/vid2",
      id: "vid_2"
   }
]